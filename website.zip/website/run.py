import os
from flask import Flask,render_template,request,url_for,redirect,session,flash
import config
from models import User
from form import RegistForm, LoginForm, PostForm,AccountForm,PasswordForm,CommentForm
from exts import db
from flask_login import login_required, current_user,logout_user, login_user,LoginManager
from werkzeug.security import generate_password_hash, check_password_hash


app = Flask(__name__)
app.config.from_object(config)
db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

#This function allow users to sign up
@app.route('/regist/', methods =['GET','POST'])
def regist():
    form = RegistForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data, method='sha256')
        user = User(username = form.username.data, email = form.email.data,
                     password = hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('You have successfully registered.','success')
        return redirect(url_for('login'))
    return render_template('regist.html', form = form)

#This function allow users to log in
@app.route('/login/', methods =['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email= form.email.data).first()
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user, remember = form.remember.data)
                return redirect(url_for('index'))
            else:
                flash('The password you entered is incorrect, please re-enter!', 'danger')
        else:
            flash('Email has not registered yet, please re-enter', 'danger')
    return render_template('login.html', form = form)   

#This function allow users to log out.
@app.route('/logout/')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run()