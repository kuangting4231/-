from datetime import datetime
from exts import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    __tablename__ = 'User'
    id = db.Column(db.Integer, primary_key = True,autoincrement = True)
    username = db.Column(db.String(50),nullable = False, unique = True)
    email= db.Column(db.String(100),nullable = False, unique = True)
    password = db.Column(db.String(100),nullable = False)
    images = db.Column(db.String(100), nullable = False, default = 'default.jpg')


    def __repr__(self):
        return  f"User('{self.username}','{self.email}','{self.images}')"

