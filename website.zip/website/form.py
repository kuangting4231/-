from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,SubmitField,BooleanField,TextAreaField
from wtforms.validators import DataRequired,Email,EqualTo,ValidationError
from models import User
from flask_login import current_user
from flask_wtf.file import FileField,FileAllowed

class RegistForm(FlaskForm):
    username = StringField('用户名', validators=[DataRequired()])
    email = StringField('电子邮件', validators=[DataRequired(), Email()])
    password = PasswordField('密码', validators=[DataRequired()])
    password2 = PasswordField('确认密码', validators= [DataRequired(), EqualTo("password", "The passwords you entered are different. Please re-enter after checking.")])
    submit = SubmitField('注册')

    #This function checks if the username entered by the user already exists
    def check_username(self,username):
        user = User.query.filter_by(username = username.data).first()
        if user:
            raise ValidationError('This username is already used, please choose another one')

        # This function checks if the email entered by the user already exists
    def check_email(self, email):
        user = User.query.filter_by(email= email.data).first()
        if user:
            raise ValidationError('This email is already registed, please choose another one')

        # This function check if the password is good


class LoginForm(FlaskForm):
    email = StringField('电子邮件', validators=[DataRequired(), Email()])
    password = PasswordField('密码', validators=[DataRequired()])
    remember = BooleanField('记住我')
    submit = SubmitField('登录')

class PasswordForm(FlaskForm):
    old_password = PasswordField('You old password', validators =[DataRequired()] )
    new_password = PasswordField('Change password', validators=[DataRequired()])
    submit =  SubmitField('Confirm')


class PostForm(FlaskForm):
    title = StringField('title', validators=[DataRequired()])
    content = TextAreaField('content', validators=[DataRequired()])
    submit = SubmitField('Create')

class CommentForm(FlaskForm):
    content = TextAreaField('content', validators=[DataRequired()])
    submit =SubmitField('comment')

class AccountForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    image = FileField('Modify profile picture', validators=[FileAllowed(['jpg','png'])])
    submit = SubmitField('Update')

    # This function checks if the username entered by the user already exists
    def check_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username=username.data).first()
            if user:
                raise ValidationError('This username is already used, please choose another one')

        # This function checks if the email entered by the user already exists

    def check_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('This email is already registed, please choose another one')

        # This function check if the password is good